package citi.elasticsearch.model;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.elasticsearch.annotations.Document;

import lombok.AllArgsConstructor;
import lombok.Builder;
//import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
//import lombok.Getter;
import lombok.NoArgsConstructor;
//import lombok.Setter;
import lombok.Setter;

@Document(indexName="busiega-new",type="Customer", shards=2)
@Data
public class Customer implements Serializable{

	public Customer() {}

    @Id
	private String id;
	private String firstName;
	private String lastName;
	//private String sex;
	private Integer age ;
	private Integer salary;
	
	
	public Customer(String id, String firstName, String lastName, int age, int salary) {
		super();
		this.id = id;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.salary = salary;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;}
	public String getLastName() {
		return lastName;}
	public void setLastName(String lastName) {
		this.lastName = lastName;}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}

  public Integer getSalary() {
		return salary;
	}


	public void setSalary(Integer salary) {
		this.salary = salary;
	}


	@Override
	public String toString() {
		return "Customer [id=" + id + ", firstName=" + firstName + ", lastName=" + lastName + ", age=" + age
				+ ", salary=" + salary + "]";
	}
	
	
}
