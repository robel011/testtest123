package citi.elasticsearch;

import java.util.ArrayList;
import java.util.List;

//import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import citi.elasticsearch.model.Customer;
import citi.elasticsearch.repository.CustomerRepository;

@SpringBootApplication
@RestController
public class ElasticBsrApplication {
	
	@Autowired
	private CustomerRepository repo;

	public static void main(String[] args) {
		SpringApplication.run(ElasticBsrApplication.class, args);
	}
	
	@PostMapping("/saveCustomer")
	public int saveCustomer(@RequestBody List<Customer> customers) {
	   repo.save(customers);
	   return customers.size();
	}

	
//	@GetMapping("/findAll")
//	public @ResponseBody Iterable<Customer> findAllCustomers(){
//		return  repo.findAll();
//	}
	
	@GetMapping("/findAll")
	@ResponseBody   
	public List<Customer> findAllCustomers() {
	    List<Customer> customers = new ArrayList<>();
	    Iterable<Customer> customersAll = repo.findAll();
	    for (Customer customer : customersAll) {
	        customers.add(customer);
	    }
	 return customers;
	}
	
	@DeleteMapping("/delete/{id}")
	public  @ResponseBody  List<Customer> deleteCustomer(@PathVariable String id) {
		repo.delete(id);
		return  findAllCustomers();
		
	}
	
	@GetMapping("/findByName/{firstName}")
	public List<Customer> findByFirstName(@PathVariable String firstName){
		return repo.findByFirstName(firstName);
	}
}
