package citi.elasticsearch.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import citi.elasticsearch.model.Customer;
import citi.elasticsearch.service.QueryDSLService;

@RestController
public class CustomerController {

	
	@Autowired
	private QueryDSLService service;
	
	//notworking
	@GetMapping("/searchMultiField/{firstName}/{age}")
	public List<Customer> searchByMultiField(@PathVariable String firstName,@PathVariable Integer age){
		System.out.println("HHHHHHHHHHHiiiiiiiiiiiiiiiiiiiiiiiiii");
		return service.searchMultiField(firstName, age);
	}
	
 
	//working
	@GetMapping("/customSearch/{firstName}")
	public List<Customer> getCustomerByField(@PathVariable String firstName){
		return service.getCustomerSearchDate(firstName);
	}
	
	//working
	@GetMapping("/search/{text}")
	public List<Customer> doMultiMatchQuery(@PathVariable String text){
		return service.multiMatchQuery(text);
	}
	
//	@GetMapping("/findAllSorted")
//	@ResponseBody   
//	public List<Customer> findAllCustomers() {
//	    List<Customer> customers = new ArrayList<>();
//	    Iterable<Customer> customersAll = service.findAll();
//	    for (Customer customer : customersAll) {
//	        customers.add(customer);
//	    }
//	 return customers;
//	}
	
}
