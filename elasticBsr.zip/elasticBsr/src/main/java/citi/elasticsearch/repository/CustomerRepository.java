package citi.elasticsearch.repository;

import java.util.List;

import org.springframework.data.elasticsearch.repository.ElasticsearchRepository;
import org.springframework.stereotype.Repository;

import citi.elasticsearch.model.Customer;

@Repository
public interface CustomerRepository  extends ElasticsearchRepository<Customer, String>{

	List<Customer> findByFirstName(String firstName);

	//void  saveAll(List<Customer> customers);

	//void deleteById(String id);
	
	

}
