package productTest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import productTest.model.Product;
import productTest.service.ProductService;

@RestController
public class ProductController {

	@Autowired
	private ProductService productService;
	
	@RequestMapping("/products")
	public List<Product> getAllProducts(){
		return productService.getAllProducts();
	}
	
	@RequestMapping("product/{productId}")
	public Product getProductById(@PathVariable String productId) {
		return productService.getProductById(productId);
	}
	
	@RequestMapping(method=RequestMethod.POST,value="/product")
	public void addProduct(@RequestBody Product pro){
		
		productService.addPro(pro);
		//return getAllProducts();
		
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/product/{id}")
	public void updateProduct(@RequestBody Product pro, @PathVariable String id){
		
		productService.updatePro(id,pro);
		//return getAllProducts();
		
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/deleteProduct/{id}")
	public void deleteProduct( @PathVariable String id){
		
		productService.deletePro(id);
		//return getAllProducts();
		
	}
	
}
