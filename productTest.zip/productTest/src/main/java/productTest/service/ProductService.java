package productTest.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import productTest.model.Product;

@Service
public class ProductService {
	
	private List<Product> products= new ArrayList<>(Arrays.asList(new Product("1","car",10,10000.0)
			                         , new Product("2","cycle",100,100.0)
			                         ,new Product("3","truck",1,30000.0)
			                         ,new Product("4","tv",2,500.0)));

	public List<Product> getAllProducts(){
		return products;
	}
	
	public Product getProductById(String id) {
		
		return products.stream().filter(p->p.getId().equals(id)).findFirst().get();
//		Product product= new Product();
//		if(product.getId()==id) {
//			return product;
//		}
//		return null;
	}
	public void addPro(Product product) {
		products.add(product);
	}

	public void updatePro(String id, Product pro) {
		
		for(int i=1;i<=products.size();i++) {
			Product p=products.get(i);
			if(p.getId().equals(id)) {
				products.set(i, pro);
			}	
		}
	}

	public void deletePro(String id) {
	
	    products.removeIf(p->p.getId().equals(id));	
		}
}
